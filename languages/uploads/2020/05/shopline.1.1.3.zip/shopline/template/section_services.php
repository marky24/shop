
<?php 
if( shortcode_exists( 'themehunk-customizer' ) ):
do_shortcode('[themehunk-customizer section="service"]');
endif;
?>