<?php
/**
 * all file includeed
 *
 * @param  
 * @return mixed|string
 */
	require get_parent_theme_file_path( '/class-tgm-plugin-activation.php');
	require get_parent_theme_file_path('/inc/plugin-install.php');
	require get_parent_theme_file_path('/inc/admin.php');
	require get_parent_theme_file_path('/inc/breadcrumb.php');	
    require get_parent_theme_file_path('/inc/widget.php');
	//customizer
	require get_parent_theme_file_path('/customizer/customizer.php');
	require get_parent_theme_file_path('/customizer/pro-button/class-customize.php' );

	